<!DOCTYPE html>
<html>
   <head>
      <title>FUCK YOU</title>
      <meta http-equiv = "refresh" content = "2; url = https://www.xsaracenz.com" />
   </head>
   <body>
   </body>
</html>